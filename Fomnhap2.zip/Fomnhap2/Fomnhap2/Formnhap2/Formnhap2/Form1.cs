﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Formnhap2
{
    public partial class Form1 : Form
    {
        //Connection String  
            //string cs = "Data Source=DESKTOP-855S0NK;Initial Catalog=Demodb;Persist Security Info=True;User ID=sa;Password=zaq1ZAQ!";  
            //SqlConnection con;  
            //SqlDataAdapter adapt;  
            //DataTable dt;  

            public Form1()
        {
            InitializeComponent();
            
     
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'demodbDataSet.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.demodbDataSet.Users);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            usersBindingSource.AddNew();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            usersBindingSource.EndEdit();
            usersTableAdapter.Update(demodbDataSet.Users);
            MessageBox.Show("Thanh cong");    

           
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            usersBindingSource.RemoveCurrent();
        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {
            //con = new SqlConnection(cs);
            //con.Open();
            //adapt = new SqlDataAdapter("select * from Users", con);
            //dt = new DataTable();
            //adapt.Fill(dt);
           // dataGridView1.DataSource = dt;
           // con.Close();
            usersBindingSource.Filter = "Name='" + txtTimkiem.Text + "'";
            //Các dấu % giúp tìm thấy chuỗi con Minh trong các chuối khác
           
            
        }

        private void txtTimkiem_TextChanged(object sender, EventArgs e)
        {
            //con = new SqlConnection(cs);
            //con.Open();
           // adapt = new SqlDataAdapter("select * from Users where Name like '" + txtTimkiem.Text + "%'", con);
           // dt = new DataTable();
           // adapt.Fill(dt);
           // dataGridView1.DataSource = dt;
            //con.Close();
         
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      

       
    }
}
