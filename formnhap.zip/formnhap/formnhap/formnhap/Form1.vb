﻿Public Class Form1
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DemodbDataSet.Users' table. You can move, or remove it, as needed.
        Me.UsersTableAdapter.Fill(Me.DemodbDataSet.Users)
    End Sub
    Private Sub btnThem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnThem.Click
        UsersBindingSource.AddNew()
    End Sub
    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        On Error GoTo SaveErr
        UsersBindingSource.EndEdit()
        UsersTableAdapter.Update(DemodbDataSet.Users)
        MessageBox.Show("Thành công")
SaveErr: Exit Sub
    End Sub

    Private Sub btnTimkiem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnTimkiem.Click
        Dim Name = InputBox("Nhập tên muốn tìm kiếm:", "Tìm kiếm theo tên")
        UsersBindingSource.Filter = "Name='" & Name & "'"
    End Sub

    Private Sub btnXoa_Click(ByVal sender As Object, e As EventArgs) Handles btnXoa.Click
        UsersBindingSource.RemoveCurrent()
    End Sub

    
   
    Private Sub btnLoadData_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLoadData.Click

    End Sub
End Class
