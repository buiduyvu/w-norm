﻿Partial Class DemodbDataSet
      Partial Class UsersDataTable

    End Class


End Class
